from flask import Blueprint, request, jsonify, abort
from flask_login import login_required, current_user
from app.models import data_base, Comment, Post, Notification, CommentLike
from app.utils.mentions import extract_mentions, create_mentions_and_notifications

comments_blueprint = Blueprint('comments', __name__)

@comments_blueprint.route('/api/post/<int:post_id>/comment', methods=['POST'])
@login_required
def add_comment(post_id):
    post = Post.query.get_or_404(post_id)

    data = request.get_json()
    content = data.get('content', '').strip()
    parent_id = data.get('parent_id')

    if not content:
        return jsonify({'error': 'Комментарий не может быть пустым'}), 400

    if len(content) > 500:
        return jsonify({'error': 'Комментарий не может превышать 500 символов'}), 400

    if parent_id:
        parent = Comment.query.get(parent_id)
        if not parent or parent.post_id != post_id:
            return jsonify({'error': 'Родительский комментарий не существует'}), 400

    comment = Comment(
        content=content,
        user_id=current_user.id,
        post_id=post_id,
        parent_id=parent_id
    )

    data_base.session.add(comment)
    data_base.session.flush()

    mentioned_users = extract_mentions(content)
    create_mentions_and_notifications(mentioned_users, post=post, comment=comment, from_user=current_user)

    if post.user_id != current_user.id:
        notification = Notification(
            user_id=post.user_id,
            from_user_id=current_user.id,
            type='comment',
            post_id=post_id,
            comment_id=comment.id
        )
        data_base.session.add(notification)

    if parent_id:
        parent_comment = Comment.query.get(parent_id)
        if parent_comment.user_id != current_user.id and parent_comment.user_id != post.user_id:
            notification = Notification(
                user_id=parent_comment.user_id,
                from_user_id=current_user.id,
                type='reply',
                post_id=post_id,
                comment_id=comment.id
            )
            data_base.session.add(notification)

    data_base.session.commit()

    return jsonify({
        'id': comment.id,
        'content': comment.content,
        'username': current_user.username,
        'user_uuid': current_user.uuid,
        'user_id': current_user.id,
        'timestamp': comment.timestamp.strftime('%d.%m.%Y %H:%M'),
        'is_author': True,
        'is_post_author': current_user.id == post.user_id,
        'can_delete': True,
        'parent_id': comment.parent_id,
        'avatar': current_user.avatar_url() if hasattr(current_user, 'avatar_url') else None
    }), 201


@comments_blueprint.route('/api/comment/<int:comment_id>', methods=['DELETE'])
@login_required
def delete_comment(comment_id):
    comment = Comment.query.get_or_404(comment_id)
    post = Post.query.get(comment.post_id)

    if current_user.id != comment.user_id and (not post or current_user.id != post.user_id):
        abort(403)

    data_base.session.delete(comment)
    data_base.session.commit()

    return jsonify({'success': True}), 200

@comments_blueprint.route('/api/post/<int:post_id>/comments')
def get_comments(post_id):
    post = Post.query.get_or_404(post_id)
    comments = []
    for comment in post.comments:
        liked = False
        if current_user.is_authenticated:
            liked = CommentLike.query.filter_by(user_id=current_user.id, comment_id=comment.id).first() is not None
        comments.append({
            'id': comment.id,
            'content': comment.content,
            'username': comment.author.username,
            'user_uuid': comment.author.uuid,
            'user_id': comment.author.id,
            'timestamp': comment.timestamp.strftime('%d.%m.%Y %H:%M'),
            'parent_id': comment.parent_id,
            'can_delete': current_user.is_authenticated and (
                    current_user.id == comment.user_id or current_user.id == post.user_id
            ),
            'avatar': comment.author.avatar_url() if hasattr(comment.author, 'avatar_url') else None,
            'liked': liked,
            'likes_count': comment.likes.count()
        })
    return jsonify({'comments': comments})

@comments_blueprint.route('/api/comment/<int:comment_id>/like', methods=['POST'])
@login_required
def like_comment(comment_id):
    comment = Comment.query.get_or_404(comment_id)
    like = CommentLike.query.filter_by(user_id=current_user.id, comment_id=comment_id).first()
    if like:
        data_base.session.delete(like)
        liked = False
    else:
        like = CommentLike(user_id=current_user.id, comment_id=comment_id)
        data_base.session.add(like)
        liked = True

        if comment.user_id != current_user.id:
            notification = Notification(
                user_id=comment.user_id,
                from_user_id=current_user.id,
                type='like_comment',
                post_id=comment.post_id,
                comment_id=comment_id
            )
            data_base.session.add(notification)
    data_base.session.commit()
    count = CommentLike.query.filter_by(comment_id=comment_id).count()
    return jsonify({'liked': liked, 'count': count})