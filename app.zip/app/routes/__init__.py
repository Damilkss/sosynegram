from .api import api_blueprint
from .index import index_blueprint
from .auth import auth_blueprint
from .profile import profile_blueprint
from .posts import posts_blueprint
from .comments import comments_blueprint
from .notification import notifications_blueprint
from .follow import follow_blueprint