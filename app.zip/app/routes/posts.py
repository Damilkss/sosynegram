import os
import uuid
from flask import Blueprint, render_template, request, redirect, url_for, current_app
from flask_login import login_required, current_user
from app.models import data_base, Post, Media, Comment, PostLike, CommentLike
from app.utils.mentions import extract_mentions, create_mentions_and_notifications

posts_blueprint = Blueprint('posts', __name__)

ALLOWED_EXTENSIONS = {
    'photo': {'png', 'jpg', 'jpeg', 'gif'},
    'video': {'mp4', 'mov', 'avi', 'mkv'}
}

def allowed_file(filename, file_type):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS[file_type]

@posts_blueprint.route('/upload', methods=['GET', 'POST'])
@login_required
def upload():
    if request.method == 'POST':
        caption = request.form.get('caption', '')
        files = request.files.getlist('file')

        if not files or files[0].filename == '':
            return render_template('upload.html', error='Файлы не выбраны')

        if len(files) > 6:
            return render_template('upload.html', error='Можно загрузить не более 6 файлов')

        post = Post(caption=caption, user_id=current_user.id)
        data_base.session.add(post)
        data_base.session.flush()

        mentioned_users = extract_mentions(caption)
        create_mentions_and_notifications(mentioned_users, post=post, from_user=current_user)

        upload_folder = current_app.config['UPLOAD_FOLDER']
        saved_any = False
        errors = []

        for idx, file in enumerate(files):
            if file.filename == '':
                continue

            ext = file.filename.rsplit('.', 1)[1].lower() if '.' in file.filename else ''
            if ext in {'png', 'jpg', 'jpeg', 'gif'}:
                file_type = 'photo'
            elif ext in {'mp4', 'mov', 'avi', 'mkv'}:
                file_type = 'video'
            else:
                errors.append(f'Файл {file.filename} имеет недопустимый формат')
                continue

            new_filename = f"{uuid.uuid4().hex}.{ext}"
            file.save(os.path.join(upload_folder, new_filename))

            relative_path = os.path.join('uploads', new_filename).replace('\\', '/')
            media = Media(
                post_id=post.id,
                type=file_type,
                file_path=relative_path,
                order=idx
            )
            data_base.session.add(media)
            saved_any = True

        if not saved_any:
            data_base.session.rollback()
            return render_template('upload.html', error='Не удалось сохранить ни одного файла: ' + '; '.join(errors))

        data_base.session.commit()
        return redirect(url_for('index.feed'))

    return render_template('upload.html')

@posts_blueprint.route('/post/<uuid:post_uuid>')
@login_required
def view_post(post_uuid):
    post = Post.query.filter_by(uuid=str(post_uuid)).first_or_404()
    liked_post_ids = set()
    liked_comment_ids = set()
    if current_user.is_authenticated:
        if PostLike.query.filter_by(user_id=current_user.id, post_id=post.id).first():
            liked_post_ids.add(post.id)
        comment_ids = [c.id for c in post.comments]
        if comment_ids:
            comment_likes = CommentLike.query.filter(
                CommentLike.user_id == current_user.id,
                CommentLike.comment_id.in_(comment_ids)
            ).all()
            liked_comment_ids = {like.comment_id for like in comment_likes}
    return render_template(
        'post/view_post.html',
        post=post,
        liked_post_ids=liked_post_ids,
        liked_comment_ids=liked_comment_ids
    )

@posts_blueprint.route('/post/<uuid:post_uuid>/delete', methods=['POST'])
@login_required
def delete_post(post_uuid):
    post = Post.query.filter_by(uuid=str(post_uuid)).first_or_404()
    if post.author != current_user:
        return redirect(url_for('index.feed'))

    Comment.query.filter_by(post_id=post.id).delete()

    for media in post.media_list:
        file_path = os.path.join(current_app.config['UPLOAD_FOLDER'], os.path.basename(media.file_path))
        if os.path.exists(file_path):
            os.remove(file_path)

    data_base.session.delete(post)
    data_base.session.commit()
    return redirect(url_for('profile.profile', user_id=current_user.id))