from flask import Blueprint, render_template, jsonify
from flask_login import login_required, current_user
from app.models import Notification, Comment, data_base

notifications_blueprint = Blueprint('notifications', __name__)

@notifications_blueprint.route('/notifications')
@login_required
def notifications_page():
    return render_template('notifications.html')

@notifications_blueprint.route('/api/notifications')
@login_required
def get_notifications():
    notifications = Notification.query.filter_by(user_id=current_user.id).order_by(Notification.timestamp.desc()).all()
    data = []
    for n in notifications:
        comment_preview = None
        if n.comment_id:
            comment = Comment.query.get(n.comment_id)
            if comment:
                preview = comment.content[:10]
                if len(comment.content) > 10:
                    preview += '...'
                comment_preview = preview

        data.append({
            'id': n.id,
            'type': n.type,
            'from_user': n.from_user.username,
            'from_user_uuid': n.from_user.uuid,
            'post_id': n.post_id,
            'comment_id': n.comment_id,
            'comment_preview': comment_preview,
            'is_read': n.is_read,
            'timestamp': n.timestamp.strftime('%d.%m.%Y %H:%M')
        })
    return jsonify(data)

@notifications_blueprint.route('/api/notifications/mark-read', methods=['POST'])
@login_required
def mark_read():
    Notification.query.filter_by(user_id=current_user.id, is_read=False).update({'is_read': True})
    data_base.session.commit()
    return jsonify({'success': True})

@notifications_blueprint.route('/api/notifications/count')
@login_required
def count():
    count = Notification.query.filter_by(user_id=current_user.id, is_read=False).count()
    return jsonify({'count': count})