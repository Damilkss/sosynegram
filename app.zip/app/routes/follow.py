from flask import Blueprint, jsonify
from flask_login import login_required, current_user
from app.models import User, Follow, Notification, data_base

follow_blueprint = Blueprint('follow', __name__)

@follow_blueprint.route('/api/profile/<string:user_uuid>/follow', methods=['POST'])
@login_required
def follow(user_uuid):
    user_to_follow = User.query.filter_by(uuid=user_uuid).first_or_404()
    if user_to_follow.id == current_user.id:
        return jsonify({'error': 'Нельзя подписаться на себя'}), 400

    if current_user.following.filter_by(id=user_to_follow.id).first():
        return jsonify({'error': 'Вы уже подписаны'}), 400

    follow = Follow(follower_id=current_user.id, followed_id=user_to_follow.id)
    data_base.session.add(follow)

    notification = Notification(
        user_id=user_to_follow.id,
        from_user_id=current_user.id,
        type='follow'
    )
    data_base.session.add(notification)

    data_base.session.commit()

    return jsonify({
        'followed': True,
        'follower_count': user_to_follow.followers.count()
    })

@follow_blueprint.route('/api/profile/<string:user_uuid>/unfollow', methods=['POST'])
@login_required
def unfollow(user_uuid):
    user_to_unfollow = User.query.filter_by(uuid=user_uuid).first_or_404()
    follow = Follow.query.filter_by(follower_id=current_user.id, followed_id=user_to_unfollow.id).first()
    if not follow:
        return jsonify({'error': 'Вы не подписаны'}), 400

    data_base.session.delete(follow)
    data_base.session.commit()

    return jsonify({
        'followed': False,
        'follower_count': user_to_unfollow.followers.count()
    })