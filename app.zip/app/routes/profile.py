import os
import uuid as uuid_lib
from flask import Blueprint, render_template, request, redirect, url_for, current_app, flash
from flask_login import login_required, current_user
from app.models import User, Post, data_base, Follow

profile_blueprint = Blueprint('profile', __name__)

ALLOWED_AVATAR_EXTENSIONS = {'png', 'jpg', 'jpeg', 'gif'}

def allowed_avatar_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_AVATAR_EXTENSIONS

@profile_blueprint.route('/profile/<string:username>')
@login_required
def profile(username):
    user = User.query.filter_by(username=username).first_or_404()
    posts = Post.query.filter_by(user_id=user.id).order_by(Post.timestamp.desc()).all()

    follower_count = user.followers.count()
    following_count = user.following.count()

    is_following = False
    if current_user.is_authenticated and current_user.id != user.id:
        is_following = Follow.query.filter_by(
            follower_id=current_user.id, followed_id=user.id
        ).first() is not None

    return render_template(
        'profile.html',
        user=user,
        posts=posts,
        follower_count=follower_count,
        following_count=following_count,
        is_following=is_following
    )

@profile_blueprint.route('/profile/<string:username>/upload_avatar', methods=['POST'])
@login_required
def upload_avatar(username):
    user = User.query.filter_by(username=username).first_or_404()
    if user.id != current_user.id:
        return redirect(url_for('profile.profile', username=user.username))

    if 'avatar' not in request.files:
        return redirect(url_for('profile.profile', username=user.username))

    file = request.files['avatar']
    if file.filename == '':
        return redirect(url_for('profile.profile', username=user.username))

    if not allowed_avatar_file(file.filename):
        flash('Недопустимый формат файла. Разрешены: png, jpg, jpeg, gif', 'danger')
        return redirect(url_for('profile.profile', username=user.username))

    if user.avatar:
        old_path = os.path.join(current_app.config['UPLOAD_FOLDER'], user.avatar.replace('uploads/', ''))
        if os.path.exists(old_path):
            os.remove(old_path)

    ext = file.filename.rsplit('.', 1)[1].lower()
    new_filename = f"avatar_{user.uuid}_{uuid_lib.uuid4().hex}.{ext}"
    relative_folder = os.path.join('uploads', 'avatars')
    absolute_folder = os.path.join(current_app.config['UPLOAD_FOLDER'], 'avatars')
    os.makedirs(absolute_folder, exist_ok=True)

    file.save(os.path.join(absolute_folder, new_filename))
    user.avatar = os.path.join(relative_folder, new_filename).replace('\\', '/')
    data_base.session.commit()

    return redirect(url_for('profile.profile', username=user.username))