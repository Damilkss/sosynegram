from flask import Blueprint, request, jsonify
from flask_login import login_required, current_user
from sqlalchemy import func
from app.models import Post, data_base, CommentLike, PostLike, Notification

api_blueprint = Blueprint('api', __name__)

@api_blueprint.route('/api/feed')
@login_required
def feed():
    exclude = request.args.get('exclude', '')
    exclude_list = []
    if exclude:
        try:
            exclude_list = [int(id) for id in exclude.split(',') if id.isdigit()]
        except ValueError:
            pass

    query = Post.query
    if exclude_list:
        query = query.filter(Post.id.notin_(exclude_list))

    posts = query.order_by(func.random()).limit(5).all()

    liked_post_ids = set()
    liked_comment_ids = set()
    if current_user.is_authenticated:
        post_ids = [p.id for p in posts]
        post_likes = PostLike.query.filter(
            PostLike.user_id == current_user.id,
            PostLike.post_id.in_(post_ids)
        ).all()
        liked_post_ids = {like.post_id for like in post_likes}
        comment_ids = []
        for post in posts:
            comment_ids.extend([c.id for c in post.comments])
        if comment_ids:
            comment_likes = CommentLike.query.filter(
                CommentLike.user_id == current_user.id,
                CommentLike.comment_id.in_(comment_ids)
            ).all()
            liked_comment_ids = {like.comment_id for like in comment_likes}

    has_more = query.count() > 5

    from flask import render_template
    posts_html = []
    for post in posts:
        html = render_template('post/post.html', post=post,
                               liked_post_ids=liked_post_ids,
                               liked_comment_ids=liked_comment_ids)
        posts_html.append(html)

    return jsonify({'posts': posts_html, 'has_more': has_more})

@api_blueprint.route('/api/post/<uuid:post_uuid>/like', methods=['POST'])
@login_required
def like_post(post_uuid):
    post = Post.query.filter_by(uuid=str(post_uuid)).first_or_404()


    like = PostLike.query.filter_by(
        user_id=current_user.id,
        post_id=post.id
    ).first()

    if like:
        data_base.session.delete(like)
        liked = False
    else:
        like = PostLike(user_id=current_user.id, post_id=post.id)
        data_base.session.add(like)
        liked = True

        if post.user_id != current_user.id:
            notification = Notification(
                user_id=post.user_id,
                from_user_id=current_user.id,
                type='like_post',
                post_id=post.id
            )
            data_base.session.add(notification)

    data_base.session.commit()
    count = PostLike.query.filter_by(post_id=post.id).count()
    return jsonify({'liked': liked, 'count': count})