import os

basedir = os.path.abspath(os.path.dirname(__file__))

class Config:
    SECRET_KEY = '095e8cf7db0bbeb0ee79b3644c5d0fdabfdeca44b5ce7b54e48bd1a21ae7552b'

    SESSION_COOKIE_DOMAIN = False

    SQLALCHEMY_DATABASE_URI = 'sqlite:///' + os.path.join(basedir, 'app.db')
    SQLALCHEMY_TRACK_MODIFICATIONS = False

    UPLOAD_FOLDER = os.path.join(basedir, 'static', 'uploads')
    MAX_CONTENT_LENGTH = 1024 * 1024 * 1024