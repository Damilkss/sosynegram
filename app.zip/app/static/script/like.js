// static/script/like.js

async function likePost(button) {
    const postId = button.dataset.postId;
    const csrfToken = document.querySelector('meta[name="csrf-token"]').content;
    try {
        const response = await fetch(`/api/post/${postId}/like`, {
            method: 'POST',
            headers: {
                'X-CSRFToken': csrfToken
            }
        });
        if (response.ok) {
            const data = await response.json();
            if (data.liked) {
                button.classList.add('liked');
            } else {
                button.classList.remove('liked');
            }
            button.querySelector('.likes-count').textContent = data.count;
        }
    } catch (error) {
        console.error('Error liking post:', error);
    }
}

async function likeComment(button) {
    const commentId = button.dataset.commentId;
    const csrfToken = document.querySelector('meta[name="csrf-token"]').content;
    try {
        const response = await fetch(`/api/comment/${commentId}/like`, {
            method: 'POST',
            headers: {
                'X-CSRFToken': csrfToken
            }
        });
        if (response.ok) {
            const data = await response.json();
            if (data.liked) {
                button.classList.add('liked');
            } else {
                button.classList.remove('liked');
            }
            button.querySelector('.likes-count').textContent = data.count;
        }
    } catch (error) {
        console.error('Error liking comment:', error);
    }
}

window.likePost = likePost;
window.likeComment = likeComment;