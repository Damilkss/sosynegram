// static/script/profile.js

document.addEventListener('DOMContentLoaded', function() {
    const selectModeBtn = document.getElementById('selectModeBtn');
    const postsGrid = document.getElementById('postsGrid');
    const selectionBar = document.getElementById('selectionBar');
    const selectedCountSpan = document.getElementById('selectedCount');
    const deleteSelectedBtn = document.getElementById('deleteSelectedBtn');
    const cancelSelectionBtn = document.getElementById('cancelSelectionBtn');

    if (selectModeBtn && postsGrid) {
        let selectionMode = false;
        let selectedPosts = new Set();

        const checkboxes = Array.from(document.querySelectorAll('.post-select'));

        function updateSelectionUI() {
            const count = selectedPosts.size;
            selectedCountSpan.textContent = count;
            selectionBar.style.display = count > 0 ? 'flex' : 'none';
        }

        function handleCheckboxChange(e) {
            const checkbox = e.target;
            const postId = checkbox.closest('.grid-item').dataset.postId;
            if (checkbox.checked) {
                selectedPosts.add(postId);
            } else {
                selectedPosts.delete(postId);
            }
            updateSelectionUI();
        }

        function setSelectionMode(enable) {
            selectionMode = enable;
            if (enable) {
                postsGrid.classList.add('selection-mode');
                checkboxes.forEach(cb => cb.addEventListener('change', handleCheckboxChange));
                selectModeBtn.style.display = 'none';
                selectedPosts.clear();
                checkboxes.forEach(cb => cb.checked = false);
                updateSelectionUI();
            } else {
                postsGrid.classList.remove('selection-mode');
                checkboxes.forEach(cb => cb.removeEventListener('change', handleCheckboxChange));
                selectModeBtn.style.display = 'inline-block';
                selectionBar.style.display = 'none';
                selectedPosts.clear();
            }
        }

        selectModeBtn.addEventListener('click', () => setSelectionMode(true));
        cancelSelectionBtn.addEventListener('click', () => setSelectionMode(false));

        deleteSelectedBtn.addEventListener('click', async function() {
            if (selectedPosts.size === 0) return;
            if (!confirm(`Удалить ${selectedPosts.size} пост(ов)?`)) return;

            const csrfToken = document.querySelector('meta[name="csrf-token"]').content;
            const deletePromises = [];

            selectedPosts.forEach(postId => {
                const formData = new FormData();
                formData.append('csrf_token', csrfToken);
                deletePromises.push(
                    fetch(`/post/${postId}/delete`, {
                        method: 'POST',
                        body: formData
                    })
                );
            });

            try {
                await Promise.all(deletePromises);
                location.reload();
            } catch (error) {
                alert('Ошибка при удалении');
                console.error(error);
            }
        });

        postsGrid.addEventListener('click', (e) => {
            if (!selectionMode) return;
            const gridItem = e.target.closest('.grid-item');
            if (!gridItem) return;
            if (!e.target.closest('.post-checkbox') && !e.target.closest('a')) {
                const checkbox = gridItem.querySelector('.post-select');
                if (checkbox) {
                    checkbox.checked = !checkbox.checked;
                    const event = new Event('change', { bubbles: true });
                    checkbox.dispatchEvent(event);
                }
            }
        });
    }

    // Follow/unfollow logic
    const followBtn = document.getElementById('followBtn');
    if (followBtn) {
        followBtn.addEventListener('click', async function() {
            const userUuid = this.dataset.userUuid;
            const isFollowing = this.dataset.following === 'true';
            const url = isFollowing ? `/api/profile/${userUuid}/unfollow` : `/api/profile/${userUuid}/follow`;
            const csrfToken = document.querySelector('meta[name="csrf-token"]').content;

            try {
                const response = await fetch(url, {
                    method: 'POST',
                    headers: {
                        'X-CSRFToken': csrfToken
                    }
                });

                if (response.ok) {
                    const data = await response.json();
                    // Update button state
                    followBtn.dataset.following = data.followed ? 'true' : 'false';
                    followBtn.classList.toggle('btn-primary', data.followed);
                    followBtn.classList.toggle('btn-outline', !data.followed);
                    followBtn.querySelector('i').className = data.followed ? 'fas fa-user-minus' : 'fas fa-user-plus';
                    followBtn.querySelector('span').textContent = data.followed ? 'Отписаться' : 'Подписаться';

                    // Update follower count in stats
                    const followerSpan = document.querySelector('.profile-stats span:nth-child(2) strong');
                    if (followerSpan) {
                        followerSpan.textContent = data.follower_count;
                    }
                } else {
                    const error = await response.json();
                    alert(error.error || 'Произошла ошибка');
                }
            } catch (err) {
                console.error('Follow error:', err);
                alert('Ошибка соединения');
            }
        });
    }
});