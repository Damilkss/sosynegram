let loadedPostIds = [];
let loading = false;
let hasMore = true;
let container = document.getElementById('posts-container');
let sentinel = document.getElementById('sentinel');
let noPostsMessage = document.getElementById('no-posts-message');

async function loadPosts() {
    if (loading || !hasMore) return;
    loading = true;

    const excludeParam = loadedPostIds.join(',');
    const url = `/api/feed?exclude=${excludeParam}`;
    try {
        const response = await fetch(url);
        const data = await response.json();
        if (data.posts.length > 0) {
            data.posts.forEach(html => {
                const tempDiv = document.createElement('div');
                tempDiv.innerHTML = html;
                const postElement = tempDiv.firstElementChild;
                container.appendChild(postElement);
                const postId = postElement.dataset.postId;
                if (postId) loadedPostIds.push(parseInt(postId));
            });
            if (noPostsMessage) noPostsMessage.style.display = 'none';
        } else {
            if (loadedPostIds.length === 0 && noPostsMessage) {
                noPostsMessage.style.display = 'block';
            }
        }
        hasMore = data.has_more;
    } catch (error) {
        console.error('Error loading posts:', error);
        hasMore = false;
    } finally {
        loading = false;
    }
}

const observer = new IntersectionObserver((entries) => {
    if (entries[0].isIntersecting) {
        loadPosts();
    }
}, { threshold: 0.1 });

if (sentinel) {
    observer.observe(sentinel);
}

loadPosts();