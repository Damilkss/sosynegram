document.addEventListener('DOMContentLoaded', function() {
    const fileInput = document.getElementById('file');
    const preview = document.getElementById('filePreview');
    const uploadForm = document.getElementById('uploadForm');
    const captionInput = document.getElementById('caption');
    const csrfToken = document.querySelector('input[name="csrf_token"]').value;

    let selectedFiles = [];
    let objectUrls = [];

    function revokeAllObjectUrls() {
        objectUrls.forEach(url => URL.revokeObjectURL(url));
        objectUrls = [];
    }

    function updatePreview() {
        revokeAllObjectUrls();
        preview.innerHTML = '';

        selectedFiles.forEach((file, index) => {
            const previewItem = document.createElement('div');
            previewItem.className = 'preview-item';
            previewItem.dataset.index = index;

            const url = URL.createObjectURL(file);
            objectUrls.push(url);

            if (file.type.startsWith('image/')) {
                const img = document.createElement('img');
                img.src = url;
                img.alt = 'Preview';
                previewItem.appendChild(img);
            } else if (file.type.startsWith('video/')) {
                const video = document.createElement('video');
                video.src = url;
                video.controls = false;
                video.muted = true;
                previewItem.appendChild(video);
            }

            const removeBtn = document.createElement('span');
            removeBtn.className = 'remove-file';
            removeBtn.innerHTML = '&times;';
            removeBtn.addEventListener('click', (e) => {
                e.stopPropagation();
                removeFile(index);
            });
            previewItem.appendChild(removeBtn);

            preview.appendChild(previewItem);
        });
    }

    function removeFile(index) {
        const items = preview.children;
        for (let item of items) {
            if (item.dataset.index === index) {
                const media = item.querySelector('img, video');
                if (media && media.src.startsWith('blob:')) {
                    URL.revokeObjectURL(media.src);

                    const urlIndex = objectUrls.indexOf(media.src);
                    if (urlIndex > -1) objectUrls.splice(urlIndex, 1);
                }
                break;
            }
        }
        selectedFiles.splice(index, 1);
        updatePreview();
    }

    fileInput.addEventListener('change', function() {
        const newFiles = Array.from(this.files);

        if (selectedFiles.length + newFiles.length > 6) {
            alert('Можно загрузить не более 6 файлов');
            this.value = '';
            return;
        }

        selectedFiles = selectedFiles.concat(newFiles);

        this.value = '';
        updatePreview();
    });

    uploadForm.addEventListener('submit', function(e) {
        e.preventDefault();

        if (selectedFiles.length === 0) {
            alert('Выберите хотя бы один файл');
            return;
        }

        const formData = new FormData();
        selectedFiles.forEach((file, i) => {
            formData.append('file', file);
        });
        formData.append('caption', captionInput.value);
        formData.append('csrf_token', csrfToken);

        const submitBtn = uploadForm.querySelector('button[type="submit"]');
        const originalText = submitBtn.innerHTML;
        submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Загрузка...';
        submitBtn.disabled = true;

        fetch(uploadForm.action, {
            method: 'POST',
            body: formData
        })
        .then(async response => {
            if (response.redirected) {
                window.location.href = response.url;
            } else {
                const text = await response.text();

                const errorMatch = text.match(/<div class="alert alert-danger">([^<]+)<\/div>/);
                if (errorMatch) {
                    alert('Ошибка: ' + errorMatch[1]);
                } else {
                    alert('Ошибка при загрузке. Проверьте консоль (F12)');
                }
            }
        })
        .catch(error => {
            alert('Сетевая ошибка: ' + error.message);
        })
        .finally(() => {
            submitBtn.innerHTML = originalText;
            submitBtn.disabled = false;
        });
    });

    window.addEventListener('beforeunload', function() {
        revokeAllObjectUrls();
    });
});