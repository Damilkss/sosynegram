const lightbox = document.getElementById('lightbox');
if (lightbox) {
    const inner = lightbox.querySelector('.lightbox-inner');
    const closeBtn = lightbox.querySelector('.lightbox-close');
    const prevBtn = document.getElementById('lightboxPrev');
    const nextBtn = document.getElementById('lightboxNext');

    let currentMediaList = [];
    let currentIndex = 0;

    function closeLightbox() {
        lightbox.style.display = 'none';
        inner.innerHTML = '';
        currentMediaList = [];
        currentIndex = 0;
    }

    function openLightbox(mediaList, index) {
        currentMediaList = mediaList;
        currentIndex = index;
        updateLightboxContent();
        lightbox.style.display = 'flex';
    }

    function updateLightboxContent() {
        if (!currentMediaList.length) return;
        const media = currentMediaList[currentIndex];
        if (media.type === 'photo') {
            inner.innerHTML = `<img src="${media.src}" class="lightbox-media">`;
        } else {
            inner.innerHTML = `<video controls src="${media.src}" class="lightbox-media"></video>`;
        }
    }

    function next() {
        if (currentMediaList.length > 1) {
            currentIndex = (currentIndex + 1) % currentMediaList.length;
            updateLightboxContent();
        }
    }

    function prev() {
        if (currentMediaList.length > 1) {
            currentIndex = (currentIndex - 1 + currentMediaList.length) % currentMediaList.length;
            updateLightboxContent();
        }
    }

    window.lightbox = {
        open: openLightbox,
        close: closeLightbox,
        next: next,
        prev: prev
    };

    document.addEventListener('click', function(e) {
        const gridItem = e.target.closest('.grid-item');
        if (!gridItem) return;

        const container = gridItem.closest('.post-media-grid');
        if (!container) return;

        const allItems = container.querySelectorAll('.grid-item');
        const mediaList = Array.from(allItems).map(item => {
            const img = item.querySelector('img');
            const video = item.querySelector('video source');
            if (img) return { type: 'photo', src: img.src };
            if (video) return { type: 'video', src: video.src };
        }).filter(m => m);

        const clickedIndex = parseInt(gridItem.dataset.index, 10);
        if (mediaList.length) {
            e.preventDefault();
            openLightbox(mediaList, clickedIndex);
        }
    });

    if (prevBtn) prevBtn.addEventListener('click', function(e) {
        e.stopPropagation();
        prev();
    });
    if (nextBtn) nextBtn.addEventListener('click', function(e) {
        e.stopPropagation();
        next();
    });
    if (closeBtn) closeBtn.addEventListener('click', function(e) {
        e.stopPropagation();
        closeLightbox();
    });

    lightbox.addEventListener('click', function(e) {
        if (e.target === lightbox) closeLightbox();
    });

    document.addEventListener('keydown', function(e) {
        if (lightbox.style.display !== 'flex') return;
        if (e.key === 'Escape') closeLightbox();
        if (e.key === 'ArrowLeft') prev();
        if (e.key === 'ArrowRight') next();
    });
}