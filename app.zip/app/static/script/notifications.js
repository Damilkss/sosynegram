document.addEventListener('DOMContentLoaded', function() {
    const notificationBell = document.getElementById('notificationBell');
    const badge = document.getElementById('notificationCount');

    function updateNotificationCount() {
        fetch('/api/notifications/count')
            .then(response => response.json())
            .then(data => {
                if (data.count > 0) {
                    badge.textContent = data.count;
                    badge.style.display = 'inline';
                } else {
                    badge.style.display = 'none';
                }
            });
    }

    if (window.location.pathname === '/notifications') {
        fetch('/api/notifications')
            .then(response => response.json())
            .then(data => {
                const list = document.getElementById('notifications-list');
                if (data.length === 0) {
                    list.innerHTML = '<p class="no-notifications">Нет уведомлений</p>';
                } else {
                    let html = '';
                    data.forEach(n => {
                        let text = '';
                        if (n.type === 'comment') text = 'оставил(а) комментарий под вашим постом';
                        else if (n.type === 'reply') {
                            const preview = n.comment_preview ? n.comment_preview : '';
                            text = `ответил(а) на ваш комментарий: "${preview}"`;
                        }
                        else if (n.type === 'mention') text = 'упомянул(а) вас';
                        else if (n.type === 'like_post') text = 'оценил(а) ваш пост';
                        else if (n.type === 'like_comment') text = 'оценил(а) ваш комментарий';
                        else if (n.type === 'follow') text = 'подписался(ась) на вас';

                        let postLink = '';
                        if (n.post_id) {
                            const anchor = n.comment_id ? `#comment-${n.comment_id}` : '';
                            postLink = ` <a href="/post/${n.post_id}${anchor}">(пост)</a>`;
                        }

                        html += `
                            <div class="notification-item ${n.is_read ? '' : 'unread'}">
                                <div class="notification-icon"><i class="fas fa-user-circle"></i></div>
                                <div class="notification-content">
                                    <a href="/profile/${n.from_user_uuid}"><strong>${escapeHtml(n.from_user)}</strong></a> ${text}
                                    ${postLink}
                                </div>
                                <div class="notification-time">${n.timestamp}</div>
                            </div>
                        `;
                    });
                    list.innerHTML = html;
                }
                const csrfToken = document.querySelector('meta[name="csrf-token"]')?.content;
                fetch('/api/notifications/mark-read', {
                    method: 'POST',
                    headers: {
                        'X-CSRFToken': csrfToken
                    }
                })
                    .then(() => updateNotificationCount());
            });
    }

    updateNotificationCount();
    setInterval(updateNotificationCount, 10000);
});

function escapeHtml(unsafe) {
    return unsafe
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;")
        .replace(/'/g, "&#039;");
}