// script/comments.js

async function addComment(event, postId) {
    event.preventDefault();

    const form = event.target;
    const textarea = form.querySelector('.comment-input');
    const content = textarea.value.trim();

    if (!content) return;

    const csrfToken = form.querySelector('input[name="csrf_token"]').value;
    const parentIdInput = document.getElementById('reply_to_id');
    const parentId = parentIdInput ? parentIdInput.value : null;

    try {
        const response = await fetch(`/api/post/${postId}/comment`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRFToken': csrfToken
            },
            body: JSON.stringify({ content: content, parent_id: parentId })
        });

        if (response.ok) {
            await refreshComments(postId);

            textarea.value = '';
            updateCharCounter(textarea);
            if (parentIdInput) parentIdInput.value = '';
            const replyIndicator = document.getElementById('replyIndicator');
            if (replyIndicator) replyIndicator.style.display = 'none';
            textarea.placeholder = 'Напишите комментарий...';
        } else {
            const error = await response.json();
            alert('Ошибка: ' + (error.error || 'Не удалось добавить комментарий'));
        }
    } catch (error) {
        console.error('Error adding comment:', error);
        alert('Произошла ошибка при добавлении комментария');
    }
}

async function refreshComments(postId) {
    console.log('refreshComments started for post', postId);
    const commentsSection = document.querySelector(`.comments-section[data-post-id="${postId}"]`);
    if (!commentsSection) {
        console.warn(`Comments section for post ${postId} not found`);
        return;
    }

    try {
        const response = await fetch(`/api/post/${postId}/comments`);
        if (!response.ok) {
            console.error('refreshComments: response not OK');
            return;
        }
        const data = await response.json();

        let commentsList = commentsSection.querySelector('.comments-list');
        if (!commentsList) {
            commentsList = document.createElement('div');
            commentsList.className = 'comments-list';
            commentsSection.insertBefore(commentsList, commentsSection.querySelector('.comment-form'));
        }

        commentsList.innerHTML = '';

        if (data.comments.length === 0) {
            commentsList.innerHTML = '<p class="no-comments">Пока нет комментариев. Будьте первым!</p>';
            updateCommentsCount(commentsSection, 0);
            return;
        }

        const commentsById = {};
        const rootComments = [];

        data.comments.forEach(c => {
            commentsById[c.id] = { ...c, children: [] };
        });

        data.comments.forEach(c => {
            if (c.parent_id && commentsById[c.parent_id]) {
                commentsById[c.parent_id].children.push(commentsById[c.id]);
            } else {
                rootComments.push(commentsById[c.id]);
            }
        });

        const sortByTime = (a, b) => new Date(a.timestamp) - new Date(b.timestamp);
        rootComments.sort(sortByTime);

        rootComments.forEach(c => {
            const commentEl = createCommentElement(c);
            commentsList.appendChild(commentEl);
            appendReplies(commentEl, c.children);
        });

        updateCommentsCount(commentsSection, data.comments.length);

        // После перерисовки проверяем, нужно ли перейти к комментарию из URL
        scrollToCommentFromHash();

    } catch (error) {
        console.error('Error refreshing comments:', error);
    }
}

function appendReplies(parentEl, replies) {
    if (!replies.length) return;

    let repliesDiv = parentEl.querySelector('.comment-replies');
    if (!repliesDiv) {
        repliesDiv = document.createElement('div');
        repliesDiv.className = 'comment-replies';
        const commentContent = parentEl.querySelector('.comment-content');
        commentContent.appendChild(repliesDiv);
    }

    replies.sort((a, b) => new Date(a.timestamp) - new Date(b.timestamp));

    // Если ответов больше 5, показываем только первые 5, остальные скрываем
    const total = replies.length;
    const visible = replies.slice(0, 5);
    const hidden = replies.slice(5);

    visible.forEach(reply => {
        const replyEl = createCommentElement(reply);
        repliesDiv.appendChild(replyEl);
        appendReplies(replyEl, reply.children);
    });

    if (hidden.length > 0) {
        const collapseDiv = document.createElement('div');
        collapseDiv.className = 'replies-collapse';

        const showMoreBtn = document.createElement('button');
        showMoreBtn.className = 'show-more-replies-btn';
        showMoreBtn.dataset.commentId = parentEl.dataset.commentId;
        showMoreBtn.textContent = `Показать ещё ${hidden.length} ответов`;

        const hiddenDiv = document.createElement('div');
        hiddenDiv.className = 'hidden-replies';
        hiddenDiv.style.display = 'none';

        hidden.forEach(reply => {
            const replyEl = createCommentElement(reply);
            hiddenDiv.appendChild(replyEl);
            appendReplies(replyEl, reply.children);
        });

        collapseDiv.appendChild(showMoreBtn);
        collapseDiv.appendChild(hiddenDiv);
        repliesDiv.appendChild(collapseDiv);

        showMoreBtn.addEventListener('click', function() {
            hiddenDiv.style.display = 'block';
            showMoreBtn.style.display = 'none';
        });
    }
}

function createCommentElement(comment) {
    const div = document.createElement('div');
    div.className = 'comment-item';
    div.dataset.commentId = comment.id;
    div.dataset.parentId = comment.parent_id || '';

    const canDelete = comment.can_delete || false;

    let avatarHtml = '<i class="fas fa-user-circle"></i>';
    if (comment.avatar && !comment.avatar.includes('default-avatar')) {
        avatarHtml = `<img src="${comment.avatar}" alt="Avatar" class="avatar-small">`;
    }

    div.innerHTML = `
        <div class="comment-avatar">${avatarHtml}</div>
        <div class="comment-content">
            <div class="comment-header">
                <a href="/profile/${comment.username}" class="comment-author">
                    ${escapeHtml(comment.username)}
                </a>
                <span class="comment-date">${comment.timestamp}</span>
                <button class="comment-reply-btn" onclick="setReplyTo(${comment.id}, '${escapeHtml(comment.username)}')">
                    <i class="fas fa-reply"></i> Ответить
                </button>
                ${canDelete ? `
                <button class="comment-delete-btn" onclick="deleteComment(${comment.id})" title="Удалить">
                    <i class="fas fa-trash"></i>
                </button>
                ` : ''}
            </div>
            <p class="comment-text">${replaceMentions(comment.content)}</p>
        </div>
    `;

    return div;
}

function setReplyTo(commentId, username) {
    const replyToId = document.getElementById('reply_to_id');
    const replyIndicator = document.getElementById('replyIndicator');
    const replyToUsernameSpan = document.getElementById('replyToUsername');
    const commentInput = document.querySelector('.comment-input');

    if (!replyToId || !replyIndicator || !replyToUsernameSpan || !commentInput) return;

    replyToId.value = commentId;
    replyToUsernameSpan.textContent = `@${username}`;
    replyIndicator.style.display = 'block';
    commentInput.focus();
    commentInput.placeholder = `Ответить ${username}...`;
}

async function deleteComment(commentId) {
    if (!confirm('Удалить комментарий?')) return;

    const commentElement = document.querySelector(`.comment-item[data-comment-id="${commentId}"]`);
    if (!commentElement) {
        alert('Комментарий не найден на странице');
        return;
    }
    const postCard = commentElement.closest('.post-card');
    if (!postCard) {
        alert('Не удалось определить пост');
        return;
    }
    const postId = postCard.dataset.postId;
    if (!postId) {
        alert('ID поста не найден');
        return;
    }

    const csrfToken = document.querySelector('meta[name="csrf-token"]')?.content;

    try {
        const response = await fetch(`/api/comment/${commentId}`, {
            method: 'DELETE',
            headers: {
                'X-CSRFToken': csrfToken
            }
        });

        if (response.ok) {
            await refreshComments(postId);
        } else {
            alert('Не удалось удалить комментарий');
        }
    } catch (error) {
        console.error('Error deleting comment:', error);
        alert('Произошла ошибка при удалении комментария');
    }
}

function updateCommentsCount(commentsSection, newCount) {
    const countSpan = commentsSection.querySelector('.comments-count');
    if (countSpan) {
        countSpan.textContent = newCount;
    }
}

function updateCharCounter(textarea) {
    const counter = textarea.closest('.comment-form')?.querySelector('.current-length');
    if (counter) {
        counter.textContent = textarea.value.length;
    }
}

function escapeHtml(unsafe) {
    return unsafe
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;")
        .replace(/'/g, "&#039;");
}

function replaceMentions(text) {
    // Сначала экранируем HTML, потом заменяем ссылки и @username
    const escaped = escapeHtml(text);

    // Сначала заменяем URL (до обработки @, чтобы не конфликтовали)
    const withLinks = escaped.replace(/(https?:\/\/[^\s<>"']+)/g, (url) => {
        return `<a href="${url}" class="mention" target="_blank" rel="noopener noreferrer">${url}</a>`;
    });

    // Затем заменяем @username
    return withLinks.replace(/@([\w]+)/g, (match, username) => {
        return `<a href="/profile/${username}" class="mention">@${username}</a>`;
    });
}

// Прокрутка к комментарию из URL (например, #comment-123)
function scrollToCommentFromHash() {
    const hash = window.location.hash;
    if (hash && hash.startsWith('#comment-')) {
        const commentId = hash.replace('#comment-', '');
        const commentElement = document.querySelector(`.comment-item[data-comment-id="${commentId}"]`);
        if (commentElement) {
            // Раскрываем все родительские свернутые блокы, если нужно
            let parent = commentElement.parentElement.closest('.comment-item');
            while (parent) {
                const hiddenReplies = parent.querySelector('.hidden-replies');
                if (hiddenReplies && hiddenReplies.style.display === 'none') {
                    const btn = parent.querySelector('.show-more-replies-btn');
                    if (btn) btn.click();
                }
                parent = parent.parentElement.closest('.comment-item');
            }

            // Плавная прокрутка
            commentElement.scrollIntoView({ behavior: 'smooth', block: 'center' });
            // Подсветка
            commentElement.style.transition = 'background-color 1s';
            commentElement.style.backgroundColor = '#fff9c4';
            setTimeout(() => {
                commentElement.style.backgroundColor = '';
            }, 2000);
        }
    }
}

document.addEventListener('DOMContentLoaded', function() {
    const textareas = document.querySelectorAll('.comment-input');
    textareas.forEach(textarea => {
        textarea.addEventListener('input', function() {
            updateCharCounter(this);
        });
    });

    const cancelReplyBtn = document.getElementById('cancelReplyBtn');
    if (cancelReplyBtn) {
        cancelReplyBtn.addEventListener('click', function() {
            const replyToId = document.getElementById('reply_to_id');
            const replyIndicator = document.getElementById('replyIndicator');
            const commentInput = document.querySelector('.comment-input');
            if (replyToId) replyToId.value = '';
            if (replyIndicator) replyIndicator.style.display = 'none';
            if (commentInput) commentInput.placeholder = 'Напишите комментарий...';
        });
    }

    scrollToCommentFromHash();

    window.addEventListener('hashchange', scrollToCommentFromHash);
});

window.addComment = addComment;
window.setReplyTo = setReplyTo;
window.deleteComment = deleteComment;

if (!document.querySelector('meta[name="csrf-token"]')) {
    const csrfToken = document.querySelector('input[name="csrf_token"]')?.value;
    if (csrfToken) {
        const meta = document.createElement('meta');
        meta.name = 'csrf-token';
        meta.content = csrfToken;
        document.head.appendChild(meta);
    }
}