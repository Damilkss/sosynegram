import re
from app.models import User, Mention, Notification, data_base

MENTION_REGEX = re.compile(r'@([a-zA-Zа-яА-Я0-9_]+)')

def extract_mentions(text):
    if not text:
        return []
    mentions = MENTION_REGEX.findall(text)

    seen = set()
    unique = []
    for username in mentions:
        if username not in seen:
            seen.add(username)
            unique.append(username)
    return unique

def create_mentions_and_notifications(usernames, post=None, comment=None, from_user=None):
    if not from_user:
        return

    for username in usernames:
        user = User.query.filter_by(username=username).first()
        if user and user.id != from_user.id:
            mention = Mention(
                user_id=user.id,
                post_id=post.id if post else None,
                comment_id=comment.id if comment else None
            )
            data_base.session.add(mention)

            notification = Notification(
                user_id=user.id,
                from_user_id=from_user.id,
                type='mention',
                post_id=post.id if post else None,
                comment_id=comment.id if comment else None
            )
            data_base.session.add(notification)