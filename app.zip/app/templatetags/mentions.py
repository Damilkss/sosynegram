import re
from flask import url_for
from app.models import User

MENTION_REGEX = re.compile(r'@([a-zA-Zа-яА-Я0-9_]+)')
URL_REGEX = re.compile(r'(https?://[^\s<>"\']+)')

def replace_mentions(text):
    def url_repl(match):
        url = match.group(1)
        return f'<a href="{url}" class="mention" target="_blank" rel="noopener noreferrer">{url}</a>'

    text = URL_REGEX.sub(url_repl, text)

    def mention_repl(match):
        username = match.group(1)
        user = User.query.filter_by(username=username).first()
        if user:
            return f'<a href="{url_for("profile.profile", username=user.username)}" class="mention">@{username}</a>'
        return f'@{username}'

    return MENTION_REGEX.sub(mention_repl, text)
