import os

from flask import Flask

from .config import Config

from .models import data_base
from .models import login_manager
from .models import csrf

from .routes import api_blueprint
from .routes import index_blueprint
from .routes import auth_blueprint
from .routes import profile_blueprint
from .routes import posts_blueprint
from .routes import comments_blueprint
from .routes import notifications_blueprint
from .routes.follow import follow_blueprint

from .templatetags.mentions import replace_mentions

def create_app() -> Flask:
    app = Flask(__name__)
    app.config.from_object(Config)

    data_base.init_app(app)

    login_manager.init_app(app)
    login_manager.login_view = 'auth.login'
    login_manager.login_message = 'Please log in to access this page.'

    csrf.init_app(app)

    app.jinja_env.filters['replace_mentions'] = replace_mentions

    app.register_blueprint(api_blueprint)
    app.register_blueprint(index_blueprint)
    app.register_blueprint(auth_blueprint)
    app.register_blueprint(profile_blueprint)
    app.register_blueprint(posts_blueprint)
    app.register_blueprint(comments_blueprint)
    app.register_blueprint(notifications_blueprint)
    app.register_blueprint(follow_blueprint)

    os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)

    with app.app_context():
        data_base.create_all()

    return app