from datetime import datetime
from sqlalchemy.orm import backref

from app.models import data_base

class Comment(data_base.Model):
    id = data_base.Column(data_base.Integer, primary_key=True)
    content = data_base.Column(data_base.String(500), nullable=False)
    timestamp = data_base.Column(data_base.DateTime, default=datetime.now)

    user_id = data_base.Column(data_base.Integer, data_base.ForeignKey('user.id'), nullable=False)
    post_id = data_base.Column(data_base.Integer, data_base.ForeignKey('post.id', ondelete='CASCADE'), nullable=False)

    post = data_base.relationship('Post', backref='comments')

    parent_id = data_base.Column(data_base.Integer, data_base.ForeignKey('comment.id', ondelete='CASCADE'), nullable=True)

    replies = data_base.relationship('Comment', backref=backref('parent', remote_side=[id]), lazy='dynamic')

    mentions = data_base.relationship('Mention', back_populates='comment', lazy=True, cascade='all, delete-orphan')

    likes = data_base.relationship('CommentLike', back_populates='comment', lazy='dynamic', cascade='all, delete-orphan')