from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager
from flask_wtf import CSRFProtect

data_base = SQLAlchemy()
login_manager = LoginManager()
csrf = CSRFProtect()

from .auth import User
from .post import Post
from .post import Media
from .comment import Comment
from .notification import Notification
from .notification import Mention
from .like import PostLike
from .like import CommentLike
from .like import Follow

@login_manager.user_loader
def load_user(user_id) -> User:
    return User.query.get(int(user_id))