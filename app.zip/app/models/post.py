from datetime import datetime
from uuid import uuid4

from app.models import data_base

class Post(data_base.Model):
    id = data_base.Column(data_base.Integer, primary_key=True)

    uuid = data_base.Column(data_base.String(36), unique=True, nullable=False, default=lambda: str(uuid4()))

    user_id = data_base.Column(data_base.Integer, data_base.ForeignKey('user.id'), nullable=False)
    caption = data_base.Column(data_base.String(200))
    timestamp = data_base.Column(data_base.DateTime, default=datetime.now)

    media_list = data_base.relationship('Media', backref='post', lazy=True, cascade='all, delete-orphan')
    mentions = data_base.relationship('Mention', back_populates='post', lazy=True, cascade='all, delete-orphan')

    likes = data_base.relationship('PostLike', back_populates='post', lazy='dynamic', cascade='all, delete-orphan')

class Media(data_base.Model):
    id = data_base.Column(data_base.Integer, primary_key=True)
    post_id = data_base.Column(data_base.Integer, data_base.ForeignKey('post.id'), nullable=False)
    type = data_base.Column(data_base.String(10), nullable=False)
    file_path = data_base.Column(data_base.String(200), nullable=False)
    order = data_base.Column(data_base.Integer, default=0)