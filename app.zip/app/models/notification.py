from datetime import datetime
from app.models import data_base

class Notification(data_base.Model):
    id = data_base.Column(data_base.Integer, primary_key=True)
    user_id = data_base.Column(data_base.Integer, data_base.ForeignKey('user.id'), nullable=False)
    from_user_id = data_base.Column(data_base.Integer, data_base.ForeignKey('user.id'), nullable=False)
    type = data_base.Column(data_base.String(50), nullable=False)
    post_id = data_base.Column(data_base.Integer, data_base.ForeignKey('post.id', ondelete='CASCADE'), nullable=True)
    comment_id = data_base.Column(data_base.Integer, data_base.ForeignKey('comment.id', ondelete='CASCADE'), nullable=True)
    is_read = data_base.Column(data_base.Boolean, default=False)
    timestamp = data_base.Column(data_base.DateTime, default=datetime.now)

    user = data_base.relationship(
        'User',
        foreign_keys=[user_id],
        back_populates='notifications'
    )
    from_user = data_base.relationship(
        'User',
        foreign_keys=[from_user_id],
        back_populates='sent_notifications'
    )

    post = data_base.relationship('Post')
    comment = data_base.relationship('Comment')


class Mention(data_base.Model):
    id = data_base.Column(data_base.Integer, primary_key=True)
    user_id = data_base.Column(data_base.Integer, data_base.ForeignKey('user.id'), nullable=False)
    post_id = data_base.Column(data_base.Integer, data_base.ForeignKey('post.id', ondelete='CASCADE'), nullable=True)
    comment_id = data_base.Column(data_base.Integer, data_base.ForeignKey('comment.id', ondelete='CASCADE'), nullable=True)

    user = data_base.relationship(
        'User',
        foreign_keys=[user_id],
        back_populates='mentions'
    )
    post = data_base.relationship('Post', back_populates='mentions')
    comment = data_base.relationship('Comment', back_populates='mentions')