from datetime import datetime
from app.models import data_base

class PostLike(data_base.Model):
    id = data_base.Column(data_base.Integer, primary_key=True)
    user_id = data_base.Column(data_base.Integer, data_base.ForeignKey('user.id'), nullable=False)
    post_id = data_base.Column(data_base.Integer, data_base.ForeignKey('post.id', ondelete='CASCADE'), nullable=False)
    timestamp = data_base.Column(data_base.DateTime, default=datetime.now)
    user = data_base.relationship('User', backref='post_likes')
    post = data_base.relationship('Post', back_populates='likes')
    __table_args__ = (data_base.UniqueConstraint('user_id', 'post_id', name='unique_user_post_like'),)

class CommentLike(data_base.Model):
    id = data_base.Column(data_base.Integer, primary_key=True)
    user_id = data_base.Column(data_base.Integer, data_base.ForeignKey('user.id'), nullable=False)
    comment_id = data_base.Column(data_base.Integer, data_base.ForeignKey('comment.id', ondelete='CASCADE'), nullable=False)
    timestamp = data_base.Column(data_base.DateTime, default=datetime.now)
    user = data_base.relationship('User', backref='comment_likes')
    comment = data_base.relationship('Comment', back_populates='likes')
    __table_args__ = (data_base.UniqueConstraint('user_id', 'comment_id', name='unique_user_comment_like'),)

class Follow(data_base.Model):
    __tablename__ = 'follows'
    follower_id = data_base.Column(data_base.Integer, data_base.ForeignKey('user.id'), primary_key=True)
    followed_id = data_base.Column(data_base.Integer, data_base.ForeignKey('user.id'), primary_key=True)
    timestamp = data_base.Column(data_base.DateTime, default=datetime.now)